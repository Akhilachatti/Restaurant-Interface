import { combineReducers } from "redux";
import tablereducer from "./tablereducer";


const reducer=combineReducers({
    tablereducer:tablereducer
})

export default reducer;