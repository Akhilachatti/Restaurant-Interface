import React from 'react'

const orders = () => {
  return (
    <div>
      <center>
        <h4>
            Orders component
        </h4>
      </center>
    </div>
  )
}

export default orders
