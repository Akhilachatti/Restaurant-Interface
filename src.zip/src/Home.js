import React from 'react';
import Table from './Container/Table';
import Header from './Container/Header';
import Filter from './Container/Filter';
import Card from './Container/Card';
 

const Home = () => {
  return (
    <div>
        <Header />
        <Table />
        <Filter />
        <Card />
    </div>
  )
}

export default Home
