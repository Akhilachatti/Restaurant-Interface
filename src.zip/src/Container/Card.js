import React, { useEffect } from 'react'

const Card = () => {
    const [data,setData]=React.useState([]);
    React.useEffect(()=>{
        fetch('http://localhost:5000/api/food').then(
           response =>response.json()
        ).then(
            json =>{
                setData(json.items)
            }
        )
    },[])
  return (
    <div>
        <center>
            {data.length >0?
            <div className='container'>
                <div className='row'>
                    {data.map((item,index) =>(
                        <div key={index} className='col-md-4' style={{padding:"5px"}}>
                         <div className='card' style={{width:"18rem",padding:"3px"}}>
                            <img src={item.url} className='card-img-top'/>
                            <div className='card-body'>
                                <h5 className='card-title'>{item.name}</h5>
                                <div className='card-text'>Rs.{item.price}</div>
                                <button className='btn btn-primary'>Order</button>
                            </div>
                         </div>

                        </div>

                    ))}
                </div>

            </div>
            :
            <div className='spinners-border text-primary'></div>
            }
        </center>
      
    </div>
  )
}

export default Card
